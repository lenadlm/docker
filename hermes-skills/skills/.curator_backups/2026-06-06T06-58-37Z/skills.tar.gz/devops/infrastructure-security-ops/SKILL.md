---
name: infrastructure-security-ops
description: "Umbrella skill for host security monitoring, docker health, and maintenance reporting workflows."
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [monitoring, security, host, docker, fail2ban, crowdsec, auditd, automation]
    related_skills: [host-security-monitoring, docker-health, maintenance-reporting]
category: devops
---

# Infrastructure Security & Monitoring OPS (umbrella)

This umbrella skill consolidates class-level patterns for host security monitoring, Docker health, and automated Hermes-driven reporting. It is designed to be extended with session-specific references and templates, so future sessions can quickly reproduce or adapt successful workflows.

## Scope
- Fail2Ban monitoring (bans/unbans, trends) and report shaping
- CrowdSec decisions and sensor relevance
- Auditd events (login failures, suspicious activity)
- Docker daemon health, container statuses, open ports, and disk usage
- Hermes-driven daily reports to Telegram
- Safe cleanup and maintenance patterns (container/image cleanup, verification)

## Triggers / Capabilities
1) Fail2Ban: derive today’s bans/unbans; surface top offenders
2) CrowdSec: summarize active decisions and notable sensors
3) Auditd: count failed logins today; surface top IPs/accounts
4) Docker: health, containers, ports, disk usage; detect unhealthy containers
5) Hermes: deliver digest to Telegram; maintain a clean, skimmable layout

## Pitfalls / Learnings
- **Reporting Preference:** Use grouping bullets/emoji for tabular data. **NEVER use pipe tables** (unsupported in Telegram).
- **Tailscale Configuration:** If running `tailscale up` to change settings (e.g., `--accept-routes`), you MUST explicitly include all current non-default flags (like `--advertise-exit-node`) or the command will fail with an error about missing flags.
- **Service Logic (Auditd):** Query via `ausearch -m USER_LOGIN -ts today --success no` to catch current-day failures.
- **Docker Cleanup:** Before removing images, check for running containers and hidden tags (e.g., `portainer/agent` vs `portainer-agent`).

## Verification Checklist
- [ ] All sub-tasks render as labeled bullets with emojis
- [ ] Delivery destination remains consistent
- [ ] No PII in daily summaries
- [ ] References exist for session replay

## Monitoring Reports & Scheduling (User Persistence)

### Report Formatting
- **Visuals:** Use emojis (🛡, 🐳, 🔍, 🆕) and bullet lists.
- **Tables:** **STRICTLY PROHIBITED.** Telegram does not render pipe tables. Use labeled key-value pairs or group bullets.
- **Content:** Provide summary first. No raw JSON; only human-readable reports.

### Security, Docker, & Tailscale Patterns
- **Tailscale:** Check backend state and MagicDNS connectivity via `tailscale status --json`. Monitor for "Some peers are advertising routes but --accept-routes is false" health warnings.
- **Docker Cooldowns:** When a specific container (e.g., `hlr-login`) needs a restart delay, use a one-time cron job (`repeat: once`) to handle the wait time.
- **Disk Usage:** Include `docker system df` details for image, volume, and build cache bloat.

### Daily Schedule
- **09:00:** Security (Fail2bit, CrowdSec, Auditd).
- **10:00:** Docker (Health, Usage, Disk).
- **11:00:** Hermes & Maintenance (Version, Changelog, Packages).

## Examples / Commands (non-exhaustive)
- Fail2Ban: sudo fail2ban-client status
- CrowdSec: sudo cscli decisions list -o json
- Auditd: sudo ausearch -m USER_LOGIN -ts today --success no
- Docker: docker info, docker ps -a, docker system df
- Hermes: hermes --version; hermes update
- Tailscale: tailscale status; systemctl status tailscaled

## References
- links to session-specific files will be added under references/ as needed
- `references/security_report.py`: Script for security summaries.
- `references/docker_report.py`: Script for docker summaries.
- `references/maintenance_report.py`: Script for maintenance/version summaries.

