---
name: opnsense-network-audit-automation
category: network-engineering
description: Robust, production-ready OPNsense network audit automation for 3-hour interval audits, read-only, Telegram delivery.
version: 1
author: Leo (Lily)
tags: [opnsense, audit, telegram, nmap, auditd, docker, security, reporting]
---

# Skill: OPNsense Network Audit Automation

Goal: Provide automated, reproducible audit reports for srv via OPNsense, including system health, auditd, docker, and logs.

Prerequisites:
- Access to srv (100.70.60.70) with SSH key at ~/.hermes/srv_id_rsa
- Telegram bot token and chat id present in environment or skill context
- Tools: nmap, aureport, docker, journalctl, dmesg, auth log, etc. on srv
- Root permissions via sudo for audit/log commands as defined

Workflow:
- Run every 3 hours
- Read-only (no destructive actions)
- Output Markdown report
- Deliver to Telegram

Plan:
- Create /tmp/srv_system_report.sh on srv (authorized)
- Exec with sudo to gather: system info, aureport (today), docker ps, auth.log tail, dmesg
- Build Markdown with sections
- Return content to parent via Telegram

Implementation specifics:
- Commands:
  - hostnamectl, uptime, df -h
  - sudo aureport -au --summary -ts today
  - sudo aureport -x --summary -ts today
  - docker ps --format "Names\tStatus\tImage"
  - sudo tail -n 50 /var/log/auth.log
  - sudo dmesg -T --level=err,crit,alert,emerg
  - Telegram delivery: curl to bot API with Markdown

Testing:
- Manual run to verify content formatting
- Validate Telegram delivery

Security:
- Use minimal read permissions
- Avoid exposing certs or private data
- Ensure no destructive commands

Usage:
- Create script on srv
- Make executable
- Run with sudo
- Script prints Markdown to stdout and posts to Telegram
