---
name: docker-management
description: Manage Docker containers, images, volumes, networks, and Compose stacks — lifecycle ops, debugging, cleanup, and Dockerfile optimization.
version: 1.2.0
author: sprmn24
license: MIT
metadata:
  hermes:
    tags: [docker, containers, devops, infrastructure, compose, images, volumes, networks, debugging]
    category: devops
    requires_toolsets: [terminal]
---

# Docker Management

Manage Docker containers, images, volumes, networks, and Compose stacks using standard Docker CLI commands. No additional dependencies beyond Docker itself.

## When to Use

- Run, stop, restart, remove, or inspect containers
- Build, pull, push, tag, or clean up Docker images
- Work with Docker Compose (multi-service stacks)
- Manage volumes or networks
- Debug a crashing container or analyze logs
- Check Docker disk usage or free up space
- Review or optimize a Dockerfile

## Prerequisites

- Docker Engine installed and running
- User added to the `docker` group (or use `sudo`)
- Docker Compose v2 (included with modern Docker installations)
- **Backgrounding Remote Tasks**: When running `docker compose up` or `docker pull` on remote hosts via SSH, always use `background=true` with `notify_on_complete=true`. Foreground timeouts (600s) often trigger before images finish pulling or containers stabilize.
- **Permission Handling**: Ensure that volume paths on the host (e.g., `/docker/app/data`) are created and owned by the `PUID:PGID` specified in the compose file (usually 1000:1000) before starting the container to avoid "Permission Denied" startup loops.
- **External Networks**: If a compose file uses `external: true` for networks, run `docker network create <name> || true` before bringing the stack up.

Quick check:

```bash
docker --version && docker compose version
```

## Quick Reference

| Task | Command |
|------|---------|
| Run container (background) | `docker run -d --name NAME IMAGE` |
| Stop + remove | `docker stop NAME && docker rm NAME` |
| View logs (follow) | `docker logs --tail 50 -f NAME` |
| Shell into container | `docker exec -it NAME /bin/sh` |
| List all containers | `docker ps -a` |
| Build image | `docker build -t TAG .` |
| Compose up | `docker compose up -d` |
| Compose down | `docker compose down` |
| Disk usage | `docker system df` |
| Cleanup dangling | `docker image prune && docker container prune` |

### Remote Deployment

When deploying to remote hosts (e.g., via SSH to 192.168.1.220):

- **Command Syntax**: Older systems may use `docker-compose`, newer ones use the Docker CLI plugin `docker compose`. Always check with `docker compose version` first.
- **GitHub Configs**: Do not try to render GitHub raw files in a local browser (sandbox issues). Instead, pull them directly on the remote host:
  `ssh user@host "curl -sSL <raw_url> -o docker-compose.yml"`
- **Backgrounding**: Always use `background=true` with `notify_on_complete=true` for `docker compose up` on remote hosts. Pulling images can take minutes and trigger 600s tool timeouts.
- **Verification**: Use `docker ps --format '{{.Names}} {{.Status}}'` to list all containers and verify health after the pull finishes.

##### Port Mapping & Env Var Mismatch Pitfall

When deploying compose stacks from external sources (GitHub, registries), the port mapping in the `ports:` section and the `WEB_APP_PORT` (or similar `*_PORT`) env var may disagree:

```yaml
# Example mismatch — WEB_APP_PORT=3300 but port mapping forwards 3000
services:
  webapp:
    image: some/image
    environment:
      - WEB_APP_PORT=3300    # app listens inside on 3300
    ports:
      - "3300:3000"          # Docker forwards host:3300 to container:3000 ✖
```

**Result**: Connecting to the host port succeeds (Docker opens the port) but the connection resets or times out — nothing is listening on port 3000 inside the container.

**Fix**: Align the env var with the mapping:
- Set `WEB_APP_PORT=3000` to match `"3300:3000"` (app listens on 3000, Docker forwards 3300→3000)
- Or change mapping to `"3300:3300"` (leaves WEB_APP_PORT=3300, Docker forwards 3300→3300)
- Either approach works, pick the one that requires fewer changes

Always check after `docker compose up -d`:
```bash
# Check if the service is listening on the expected internal port
ssh user@host "docker logs <container> --tail 10 | grep -i listening"
# Then test the mapped port
curl -sS -o /dev/null -w '%{http_code}' --connect-timeout 5 http://localhost:<host_port>
```

#### Health Check Retry Pattern

After `docker compose up -d`, containers may need 3-10 seconds to pass their health check before serving traffic. A single immediate curl is unreliable:

```bash
# Deploy
cd /path/to/stack && docker compose up -d

# Wait for health
sleep 5

# Verify health status
docker inspect <container> --format '{{.State.Health.Status}}'
# Expected: "healthy"

# THEN test HTTP — if it fails, retry once after another sleep
curl -sS -o /dev/null -w '%{http_code}' --connect-timeout 5 http://localhost:<port>
# If "connection reset" or "000", sleep 3 and retry
```

#### Container Capabilities Pitfall — `docker update` Does NOT Support `--cap-add`

Some containers need special Linux capabilities (e.g., `NET_ADMIN` for raw socket operations, `SYS_PTRACE` for debuggers, `IPC_LOCK` for memory locking). Common symptoms of a missing capability:
```
process is missing required capability NET_ADMIN
dnsmasq: exited with status 5
```

**`docker update` does NOT support `--cap-add`**, `--cap-drop`, `--privileged`, or `--security-opt`:
```bash
# ❌ This does NOT work — "unknown flag: --cap-add"
docker update --cap-add NET_ADMIN mycontainer
```

**The fix is always in the compose file**, followed by a recreate:
```yaml
services:
  myapp:
    image: some/image
    cap_add:
      - NET_ADMIN        # or any other capability
    # cap_drop:          # also supported
    #   - ALL
    ...
```

Then recreate:
```bash
docker compose up -d    # detects compose change, recreates container
```

**For `docker run` containers** (no compose file), the only option is to stop, remove, and re-create with `--cap-add`:
```bash
# Save the run command, then:
docker stop mycontainer && docker rm mycontainer
docker run -d --cap-add NET_ADMIN --name mycontainer ...  # original args + cap-add
```

**Quick debug flow for capability errors**:
```bash
# 1. Check container logs for explicit capability errors
docker logs mycontainer 2>&1 | grep -i -E "capability|permission denied|operation not permitted"

# 2. Verify which capabilities the container currently has
docker inspect mycontainer --format '{{json .HostConfig.CapAdd}}'

# 3. Check if the process actually needs the cap by examining its binary
docker exec mycontainer getcap /usr/sbin/dnsmasq 2>/dev/null || echo "getcap not available in container"

# 4. List all supported caps on the host
capsh --print | grep Current | tr ',' '\n'
```

**Capability troubleshooting table**:

| Error | Missing Capability | Typical Container | Fix |
|-------|-------------------|-------------------|-----|
| `missing required capability NET_ADMIN` | `NET_ADMIN` | DNS/DHCP servers (dnsmasq), VPN clients (WireGuard, OpenVPN), packet capture tools | Add to compose `cap_add` |
| `Operation not permitted` (socket creation) | `NET_RAW` or `NET_ADMIN` | Ping, traceroute, raw socket apps | Add `NET_RAW` |
| `ptrace: Operation not permitted` | `SYS_PTRACE` | Debuggers, profilers | Add `SYS_PTRACE` |
| `mlockall failed: Cannot allocate memory` | `IPC_LOCK` | Databases (Redis), password managers | Add `IPC_LOCK` |

**Reference**: `references/netbootxyz-deployment.md` — full worked example with ProxyDHCP, BIOS/UEFI dual-boot, capability troubleshooting, and deployment steps on remote Docker hosts. 

---

### 1. Identify the domain

Figure out which area the request falls into:

- **Container lifecycle** → run, stop, start, restart, rm, pause/unpause
- **Container interaction** → exec, cp, logs, inspect, stats
- **Image management** → build, pull, push, tag, rmi, save/load
- **Docker Compose** → up, down, ps, logs, exec, build, config
- **Volumes & networks** → create, inspect, rm, prune, connect
- **Troubleshooting** → log analysis, exit codes, resource issues

### 2. Container operations

**Run a new container:**

```bash
# Detached service with port mapping
docker run -d --name web -p 8080:80 nginx

# With environment variables
docker run -d -e POSTGRES_PASSWORD=secret -e POSTGRES_DB=mydb --name db postgres:16

# With persistent data (named volume)
docker run -d -v pgdata:/var/lib/postgresql/data --name db postgres:16

# For development (bind mount source code)
docker run -d -v $(pwd)/src:/app/src -p 3000:3000 --name dev my-app

# Interactive debugging (auto-remove on exit)
docker run -it --rm ubuntu:22.04 /bin/bash

# With resource limits and restart policy
docker run -d --memory=512m --cpus=1.5 --restart=unless-stopped --name app my-app
```

Key flags: `-d` detached, `-it` interactive+tty, `--rm` auto-remove, `-p` port (host:container), `-e` env var, `-v` volume, `--name` name, `--restart` restart policy.

**Manage running containers:**

```bash
docker ps                        # running containers
docker ps -a                     # all (including stopped)
docker stop NAME                 # graceful stop
docker start NAME                # start stopped container
docker restart NAME              # stop + start
docker rm NAME                   # remove stopped container
docker rm -f NAME                # force remove running container
docker container prune           # remove ALL stopped containers
```

**Interact with containers:**

```bash
docker exec -it NAME /bin/sh          # shell access (use /bin/bash if available)
docker exec NAME env                   # view environment variables
docker exec -u root NAME apt update    # run as specific user
docker logs --tail 100 -f NAME         # follow last 100 lines
docker logs --since 2h NAME            # logs from last 2 hours
docker cp NAME:/path/file ./local      # copy file from container
docker cp ./file NAME:/path/           # copy file to container
docker inspect NAME                    # full container details (JSON)
docker stats --no-stream               # resource usage snapshot
docker top NAME                        # running processes
```

### 3. Image management

```bash
# Build
docker build -t my-app:latest .
docker build -t my-app:prod -f Dockerfile.prod .
docker build --no-cache -t my-app .              # clean rebuild
DOCKER_BUILDKIT=1 docker build -t my-app .       # faster with BuildKit

# Pull and push
docker pull node:20-alpine
docker login ghcr.io
docker tag my-app:latest registry/my-app:v1.0
docker push registry/my-app:v1.0

# Inspect
docker images                          # list local images
docker history IMAGE                   # see layers
docker inspect IMAGE                   # full details

# Cleanup
docker image prune                     # remove dangling (untagged) images
docker image prune -a                  # remove ALL unused images (careful!)
docker image prune -a --filter "until=168h"   # unused images older than 7 days
```

### 4. Docker Compose

```bash
# Start/stop
docker compose up -d                   # start all services detached
docker compose up -d --build           # rebuild images before starting
docker compose down                    # stop and remove containers
docker compose down -v                 # also remove volumes (DESTROYS DATA)

# Monitoring
docker compose ps                      # list services
docker compose logs -f api             # follow logs for specific service
docker compose logs --tail 50          # last 50 lines all services

# Interaction
docker compose exec api /bin/sh        # shell into running service
docker compose run --rm api npm test   # one-off command (new container)
docker compose restart api             # restart specific service

# Validation
docker compose config                  # validate and view resolved config
```

**Minimal compose.yml example:**

```yaml
services:
  api:
    build: .
    ports:
      - "3000:3000"
    environment:
      - DATABASE_URL=postgres://user:pass@db:5432/mydb
    depends_on:
      db:
        condition: service_healthy

  db:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: user
      POSTGRES_PASSWORD: pass
      POSTGRES_DB: mydb
    volumes:
      - pgdata:/var/lib/postgresql/data
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U user"]
      interval: 10s
      timeout: 5s
      retries: 5

volumes:
  pgdata:
```

### 5. Volumes and networks

```bash
# Volumes
docker volume ls                       # list volumes
docker volume create mydata            # create named volume
docker volume inspect mydata           # details (mount point, etc.)
docker volume rm mydata                # remove (fails if in use)
docker volume prune                    # remove unused volumes

# Networks
docker network ls                      # list networks
docker network create mynet            # create bridge network
docker network inspect mynet           # details (connected containers)
docker network connect mynet NAME      # attach container to network
docker network disconnect mynet NAME   # detach container
docker network rm mynet                # remove network
docker network prune                   # remove unused networks
```

### 6. Disk usage and cleanup

Always start with a diagnostic before cleaning:

```bash
# Check what's using space
docker system df                       # summary
docker system df -v                    # detailed breakdown

# Targeted cleanup (safe)
docker container prune                 # stopped containers
docker image prune                     # dangling images
docker volume prune                    # unused volumes
docker network prune                   # unused networks

# Aggressive cleanup (confirm with user first!)
docker system prune                    # containers + images + networks
docker system prune -a                 # also unused images
docker system prune -a --volumes       # EVERYTHING — named volumes too
```

**Warning:** Never run `docker system prune -a --volumes` without confirming with the user. This removes named volumes with potentially important data.

### 7. Maintenance and Updates

**Update all images and restart containers:**
This pattern is useful for keeping a fleet of containers up-to-date.

```bash
# 1. Update Docker Engine (Ubuntu/Debian)
sudo apt update && sudo apt install -y docker-ce docker-ce-cli containerd.io docker-compose-plugin

# 2. Update all Compose-managed stacks
# This finds the working directory for every running stack and pulls/ups it
stacks=$(docker ps --format '{{.Label "com.docker.compose.project.working_dir"}}' | sort -u | grep -v '^$')
for dir in $stacks; do
  if [ -d "$dir" ]; then
    echo "Updating stack in $dir..."
    cd "$dir" && docker compose pull && docker compose up -d
  fi
done

# 3. Cleanup to reclaim space
docker image prune -a -f
```

### 8. Troubleshooting Tip: Missing Compose Dirs
If `docker ps` shows a working directory label that no longer exists on the host, the container was likely deployed via a temporary tool (like Portainer or a deleted git repo). You must manually recreate these or use `docker-recycle` if the original run config is lost.


| Problem | Cause | Fix |
|---------|-------|-----|
| Container exits immediately | Main process finished or crashed | Check `docker logs NAME`, try `docker run -it --entrypoint /bin/sh IMAGE` |
| "port is already allocated" | Another process using that port | `docker ps` or `lsof -i :PORT` to find it |
| "no space left on device" | Docker disk full | `docker system df` then targeted prune |
| Can't connect to container | App binds to 127.0.0.1 inside container | App must bind to `0.0.0.0`, check `-p` mapping |
| Permission denied on volume | UID/GID mismatch host vs container | Use `--user $(id -u):$(id -g)` or fix permissions |
| Compose services can't reach each other | Wrong network or service name | Services use service name as hostname, check `docker compose config` |
| Build cache not working | Layer order wrong in Dockerfile | Put rarely-changing layers first (deps before source code) |
| Image too large | No multi-stage build, no .dockerignore | Use multi-stage builds, add `.dockerignore` |

## Verification

After any Docker operation, verify the result:

- **Container started?** → `docker ps` (check status is "Up")
- **Logs clean?** → `docker logs --tail 20 NAME` (no errors)
- **Port accessible?** → `curl -s http://localhost:PORT` or `docker port NAME`
- **Image built?** → `docker images | grep TAG`
- **Compose stack healthy?** → `docker compose ps` (all services "running" or "healthy")
- **Disk freed?** → `docker system df` (compare before/after)

## Dockerfile Optimization Tips

When reviewing or creating a Dockerfile, suggest these improvements:

1. **Multi-stage builds** — separate build environment from runtime to reduce final image size
2. **Layer ordering** — put dependencies before source code so changes don't invalidate cached layers
3. **Combine RUN commands** — fewer layers, smaller image
4. **Use .dockerignore** — exclude `node_modules`, `.git`, `__pycache__`, etc.
5. **Pin base image versions** — `node:20-alpine` not `node:latest`
6. **Run as non-root** — add `USER` instruction for security
7. **Use slim/alpine bases** — `python:3.12-slim` not `python:3.12`
