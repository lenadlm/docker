#!/usr/bin/env python3
"""
Replace TUNNEL_TOKEN=*** line in .env with a new token read from a file.

Usage:
    python3 update_token.py <token_file> <env_file>

The token file must contain ONLY the bare token value (no KEY= prefix).
The script finds the TUNNEL_TOKEN=*** line in the .env and replaces it.

Use this when a Cloudflare tunnel token needs to be rotated on a remote host.
SCP both files to the remote host first, then run via SSH:
    scp update_token.py new_token_value user@host:/tmp/
    ssh user@host "python3 /tmp/update_token.py /tmp/new_token_value /path/to/stack/.env"
"""
import sys


def main():
    if len(sys.argv) != 3:
        print(f"Usage: {sys.argv[0]} <token_file> <env_file>")
        sys.exit(1)

    token_path = sys.argv[1]
    env_path = sys.argv[2]

    token = open(token_path).read().strip()
    token_len = len(token)

    with open(env_path, 'r') as f:
        content = f.read()

    lines = content.split('\n')
    found = False
    for i, line in enumerate(lines):
        if line.startswith('TUNNEL_TOKEN='):
            old_len = len(line)
            lines[i] = f'TUNNEL_TOKEN={token}'
            found = True
            print(f'Replaced line ({old_len} chars -> {token_len + 13} chars)')
            break

    if not found:
        print(f'ERROR: TUNNEL_TOKEN= line not found in {env_path}')
        sys.exit(1)

    content = '\n'.join(lines)
    with open(env_path, 'w') as f:
        f.write(content)

    # Verify
    with open(env_path) as f:
        final = f.read()

    if token in final:
        print(f'VERIFIED: token present ({token_len} chars)')
    else:
        print('ERROR: token NOT found in written file — possible truncation')
        sys.exit(1)


if __name__ == '__main__':
    main()